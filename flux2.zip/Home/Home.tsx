import HomePage from '../components/homepage/HomePage';
import React from 'react'

const Home = () => {
  return (
    <HomePage/>
  )
}

export default Home