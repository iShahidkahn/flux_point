
import Home from '../Home/Home';
import React from "react";
const App = () => {
  return (
    <>
    <Home/>
    </>
  );
};

export default App;
