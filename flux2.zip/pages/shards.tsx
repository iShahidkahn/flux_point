import Shard from '../components/shards/Shard'
import React from 'react'

const shards = () => {
  return (
   <Shard/>
  )
}

export default shards