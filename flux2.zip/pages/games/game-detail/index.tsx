import React from 'react' 
import GameDetail from '../../../components/games/game_detail/GameDetail'
const GameDetails = () => {
  return (
  <GameDetail/>
  )
}

export default GameDetails