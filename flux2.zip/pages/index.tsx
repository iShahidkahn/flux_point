import React from "react";
import App from './app';

const index = () => {
  return (
    <>
      <div>
        <App/>
      </div>
    </>
  );
};

export default index;
