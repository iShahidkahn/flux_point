import React from 'react'
import Stackings from '../components/stackings/Stackings'

const stacking = () => {
  return (
    <Stackings/>
  )
}

export default stacking