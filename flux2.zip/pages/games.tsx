import React from "react";
import Game from "../components/games/Game";
const games = () => {
  return <Game />;
};

export default games;
