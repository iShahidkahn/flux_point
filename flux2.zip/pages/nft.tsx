import React from "react";
import NFT from "../components/nft/NFT";

export interface nftProps {}
export default function nft({}: nftProps) {
  return (
    <>
      <NFT></NFT>
    </>
  );
}
