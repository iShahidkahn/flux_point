import Career from "../components/careers/Career";
import React from "react";

const careers = () => {
  return <Career />;
};

export default careers;
