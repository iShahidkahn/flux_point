export interface SubmitStakeTransactionInput {
    paymentAddress: string;
    successTransactions?: SuccessTransaction[];
}
