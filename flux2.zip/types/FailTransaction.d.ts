import { SaturnError } from '../Classes/saturnError';

export interface FailTransaction {
    error?: SaturnError;
}
