export interface SuccessTransaction {
    transactionId?: string;
    hexTransaction?: string;
}
